package com.javainuse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleHandsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
